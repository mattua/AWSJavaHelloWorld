/*
 Copyright 2010-2016 Amazon.com, Inc. or its affiliates. All Rights Reserved.

 Licensed under the Apache License, Version 2.0 (the "License").
 You may not use this file except in compliance with the License.
 A copy of the License is located at

 http://aws.amazon.com/apache2.0

 or in the "license" file accompanying this file. This file is distributed
 on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 express or implied. See the License for the specific language governing
 permissions and limitations under the License.
 */
 

#import <Foundation/Foundation.h>
#import <AWSAPIGateway/AWSAPIGateway.h>

#import "MATTUA-PROD-COMMENTSEmpty.h"

/**
 The service client object.
 */
@interface MATTUA-PROD-COMMENTSCommentsApiClient: AWSAPIGatewayClient

/**
 Returns the singleton service client. If the singleton object does not exist, the SDK instantiates the default service client with `defaultServiceConfiguration` from `[AWSServiceManager defaultServiceManager]`. The reference to this object is maintained by the SDK, and you do not need to retain it manually.

 If you want to enable AWS Signature, set the default service configuration in `- application:didFinishLaunchingWithOptions:`
 
 *Swift*

     func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
         let credentialProvider = AWSCognitoCredentialsProvider(regionType: .USEast1, identityPoolId: "YourIdentityPoolId")
         let configuration = AWSServiceConfiguration(region: .USEast1, credentialsProvider: credentialProvider)
         AWSServiceManager.defaultServiceManager().defaultServiceConfiguration = configuration

         return true
     }

 *Objective-C*

     - (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
          AWSCognitoCredentialsProvider *credentialsProvider = [[AWSCognitoCredentialsProvider alloc] initWithRegionType:AWSRegionUSEast1
                                                                                                          identityPoolId:@"YourIdentityPoolId"];
          AWSServiceConfiguration *configuration = [[AWSServiceConfiguration alloc] initWithRegion:AWSRegionUSEast1
                                                                               credentialsProvider:credentialsProvider];
          [AWSServiceManager defaultServiceManager].defaultServiceConfiguration = configuration;

          return YES;
      }

 Then call the following to get the default service client:

 *Swift*

     let serviceClient = MATTUA-PROD-COMMENTSCommentsApiClient.defaultClient()

 *Objective-C*

     MATTUA-PROD-COMMENTSCommentsApiClient *serviceClient = [MATTUA-PROD-COMMENTSCommentsApiClient defaultClient];

 @return The default service client.
 */
+ (instancetype)defaultClient;

/**
 Creates a service client with the given service configuration and registers it for the key.

 If you want to enable AWS Signature, set the default service configuration in `- application:didFinishLaunchingWithOptions:`

 *Swift*

     func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
         let credentialProvider = AWSCognitoCredentialsProvider(regionType: .USEast1, identityPoolId: "YourIdentityPoolId")
         let configuration = AWSServiceConfiguration(region: .USWest2, credentialsProvider: credentialProvider)
         MATTUA-PROD-COMMENTSCommentsApiClient.registerClientWithConfiguration(configuration, forKey: "USWest2MATTUA-PROD-COMMENTSCommentsApiClient")

         return true
     }

 *Objective-C*

     - (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
         AWSCognitoCredentialsProvider *credentialsProvider = [[AWSCognitoCredentialsProvider alloc] initWithRegionType:AWSRegionUSEast1
                                                                                                         identityPoolId:@"YourIdentityPoolId"];
         AWSServiceConfiguration *configuration = [[AWSServiceConfiguration alloc] initWithRegion:AWSRegionUSWest2
                                                                              credentialsProvider:credentialsProvider];

         [MATTUA-PROD-COMMENTSCommentsApiClient registerClientWithConfiguration:configuration forKey:@"USWest2MATTUA-PROD-COMMENTSCommentsApiClient"];

         return YES;
     }

 Then call the following to get the service client:

 *Swift*

     let serviceClient = MATTUA-PROD-COMMENTSCommentsApiClient(forKey: "USWest2MATTUA-PROD-COMMENTSCommentsApiClient")

 *Objective-C*

     MATTUA-PROD-COMMENTSCommentsApiClient *serviceClient = [MATTUA-PROD-COMMENTSCommentsApiClient clientForKey:@"USWest2MATTUA-PROD-COMMENTSCommentsApiClient"];

 @warning After calling this method, do not modify the configuration object. It may cause unspecified behaviors.

 @param configuration A service configuration object.
 @param key           A string to identify the service client.
 */
+ (void)registerClientWithConfiguration:(AWSServiceConfiguration *)configuration forKey:(NSString *)key;

/**
 Retrieves the service client associated with the key. You need to call `+ registerClientWithConfiguration:forKey:` before invoking this method. If `+ registerClientWithConfiguration:forKey:` has not been called in advance or the key does not exist, this method returns `nil`.

 For example, set the default service configuration in `- application:didFinishLaunchingWithOptions:`

 *Swift*

     func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
         let credentialProvider = AWSCognitoCredentialsProvider(regionType: .USEast1, identityPoolId: "YourIdentityPoolId")
         let configuration = AWSServiceConfiguration(region: .USWest2, credentialsProvider: credentialProvider)
         MATTUA-PROD-COMMENTSCommentsApiClient.registerClientWithConfiguration(configuration, forKey: "USWest2MATTUA-PROD-COMMENTSCommentsApiClient")

         return true
     }

 *Objective-C*

     - (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
         AWSCognitoCredentialsProvider *credentialsProvider = [[AWSCognitoCredentialsProvider alloc] initWithRegionType:AWSRegionUSEast1
                                                                                                         identityPoolId:@"YourIdentityPoolId"];
         AWSServiceConfiguration *configuration = [[AWSServiceConfiguration alloc] initWithRegion:AWSRegionUSWest2
                                                                              credentialsProvider:credentialsProvider];

         [MATTUA-PROD-COMMENTSCommentsApiClient registerClientWithConfiguration:configuration forKey:@"USWest2MATTUA-PROD-COMMENTSCommentsApiClient"];

         return YES;
     }

 Then call the following to get the service client:

 *Swift*

     let serviceClient = MATTUA-PROD-COMMENTSCommentsApiClient(forKey: "USWest2MATTUA-PROD-COMMENTSCommentsApiClient")

 *Objective-C*

     MATTUA-PROD-COMMENTSCommentsApiClient *serviceClient = [MATTUA-PROD-COMMENTSCommentsApiClient clientForKey:@"USWest2MATTUA-PROD-COMMENTSCommentsApiClient"];

 @param key A string to identify the service client.

 @return An instance of the service client.
 */
+ (instancetype)clientForKey:(NSString *)key;

/**
 Removes the service client associated with the key and release it.
 
 @warning Before calling this method, make sure no method is running on this client.
 
 @param key A string to identify the service client.
 */
+ (void)removeClientForKey:(NSString *)key;

/**
 
 
 
 return type: MATTUA-PROD-COMMENTSEmpty *
 */
- (AWSTask *)commentsPost;

/**
 
 
 @param pageId 
 
 return type: MATTUA-PROD-COMMENTSEmpty *
 */
- (AWSTask *)commentsPageIdGet:(NSString *)pageId;

@end
